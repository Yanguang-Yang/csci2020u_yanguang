## Read me
# a
![assignment2.png](https://i.loli.net/2021/04/04/VWUoi53bDqefs8A.png)

This project is creating a client to upload a file to the server or download a file from the server.  
There are two buttons: Upload and Download on the top, and two tables on the bottom: left is local, right is server's.
# b
Same UI as the PDF.
# c
Upload: Select one file from the left table. Click "Upload"  
Download: Select one file from the left table. Click "Download"
# d
Tutorial 4 - Code Walkthrough ChatServer Application using Sockets
ChatServer.zip