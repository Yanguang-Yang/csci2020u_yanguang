# csci2020u Midterm

Open the src/midterm2021/Main.java, then there will be 3 buttons: Animation, 2D Graphics and About.
1.Click the "Animation" button, you will see a Grey duck moving.
2.Click the "2D Graphics" button, you will see 2 graphics of my inistials.
3.Click the "About" button, you will see my information and also description of this software.
PS: Every scene's top has a link to go back to the main scene.